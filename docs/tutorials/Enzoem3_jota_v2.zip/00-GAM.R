library(here)
datos<-read.csv(here("Data","prevaleciaSim.csv"))

888888888888888888888888888888888888
PREVALENCIAS
888888888888888888888888888888888888

# Analisis de prevalencias (como %)

datos$prev<-(datos$positivos/(datos$positivos+datos$negativos))
plot(prev~densidad_sp, datos)

# Añadir línea de tendencia lineal
modelo_lineal <- lm(prev ~ densidad_sp, data = datos)
abline(modelo_lineal, col = "red", lwd = 2)
plot (modelo_lineal)

# Ajustar GLM binomial con datos agregados

m0 <- glm(cbind(positivos, negativos) ~ 1, data = datos, family = binomial)

m1 <- glm(cbind(positivos, negativos) ~ densidad_sp , data = datos, family = binomial)

plot(m1)

m2 <- glm(cbind(positivos, negativos) ~ precipitacion + habitat + gestion + densidad_sp, data = datos, family = binomial)

summary(m2)
exp(coef(m2))
exp(coef(modelo)["densidad_sp"] * 1)


m3 <- glm(cbind(positivos, negativos) ~ precipitacion + habitat + gestion + densidad_sp, data = datos, family = binomial(link = "cloglog"))

AIC(m0,m1,m2,m3)
library (effects)
plot(allEffects(m2)
     
#      
     # Log-likelihood del modelo ajustado
 ll_model <- logLik(m2) # Modelo nulo (solo intercepto)
 ll_null <- logLik(m0)# Modelo nulo (solo intercepto)
 
     # McFadden's pseudo-R²
  r2_mcfadden <- 1 - (as.numeric(ll_model) / as.numeric(ll_null))
  r2_mcfadden

  
  library(pscl)
  pR2(m2)
  
 
#SOBREDISPERSION

# Número de observaciones
n <- nrow(datos)

# Grados de libertad del modelo
df <- m2$df.residual

# Estadístico de sobredispersión
dispersion <- sum(residuals(m2, type = "deviance")^2) / df
dispersion

#ALTERNATIVAS

m2_q <- glm(cbind(positivos, negativos) ~ densidad_sp, data = datos, family = quasibinomial)
summary(m2_q)

888888888888888888888888888888888
GAM- GENERAL ADDITIVE MODEL
888888888888888888888888888888888
datos1<-read.csv("Data",".csv")

  
datos1$localidad <- as.factor(datos1$localidad)
datos1$gestion <- as.factor(datos1$gestion)
names(datos1)
str(datos1)

# Ajustar los modelos GAM
modelo_gam <- gam(
  conteo ~ 
    s(año) + # Efecto suavizado del año
    s(temperatura) + # Efecto suavizado de la temperatura
    gestion + # Efecto lineal del tipo de gestión
    ti(año, by = gestion) + # Interacción entre temperatura y gestión
    s(localidad, bs = "re"), # Efecto aleatorio para cada localidad
  data = datos1,
  family = poisson(link = "log")
)

modelo_gamQP <- gam(
  conteo ~ 
    s(año) + # Efecto suavizado del año
    s(temperatura) + # Efecto suavizado de la temperatura
    gestion + # Efecto lineal del tipo de gestión
    ti(año, by = gestion) + # Interacción entre temperatura y gestión
    s(localidad, bs = "re"), # Efecto aleatorio para cada localidad
  data = datos1,
  family = quasipoisson(link = "log")
)

modelo_gam1BN <- gam(
  conteo ~ 
    s(año) + # Efecto suavizado del año
    s(temperatura) + # Efecto suavizado de la temperatura
    gestion + # Efecto lineal del tipo de gestión
    ti(año, by = gestion) + # Interacción entre temperatura y gestión
    ti(temperatura, by = gestion)+
    s(localidad, bs = "re"), # Efecto aleatorio para cada localidad
  data = datos1,
  family = nb(link = "log")
  #family = quasipoisson(link = "log")
)

# Resumen del modelo
summary(modelo_gam)

# Visualización de los efectos
plot(modelo_gam1BN, pages = 1)
par(mfrow=c(2,2))
gam.check(modelo_gam1BN)