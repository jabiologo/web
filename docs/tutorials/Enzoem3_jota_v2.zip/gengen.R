#Librerías 
library(readxl)
library(ggplot2)
library(car)
library(lme4)
library(graphics)
library(PerformanceAnalytics)
library(MASS)
library(tidyverse)
library(here)

#Cargar datos
hoja<-"data"
datos <- read_excel(here("Data", "culicoides.xlsx"),sheet = hoja)

#Revision general de nuestros datos 
str(datos)
summary(datos)
head(datos)
names(datos)
datos$PROV_ID<-as.factor(datos$PROV_ID)
datos1 <- na.omit(datos)


88888888888888888888888888888888888888888888888888888
#===============================
# COLINEALIDAD
#===============================
#Scatterplot


vars <- datos[, c("NDVI_Aut" ,"NDVI_Spri" ,"NDVI_Sum" ,"NDVI_Win" ,"ANU_PLU" ,"ANU_T_MAX" ,"ANU_T_MED" ,"ANU_T_MIN" ,"T_agri" ,"T_forest" ,"P_capcap" ,"P_cerela" ,"xcoord" ,"ycoord")]

chart.Correlation(vars, method = "spearman", histogram = TRUE, pch = "+", main="Scatterplot de las variables")


888888888888888888888888888888888888888888
datosPCA <- datos1[c("NDVI_Aut","NDVI_Spri", "NDVI_Sum","NDVI_Win","ANU_PLU","ANU_T_MAX","ANU_T_MED","ANU_T_MIN")]

library(factoextra)# PCA
# -------------------------------
# 1. PCA (Análisis de Componentes Principales)
pca_res <- prcomp(datosPCA, center = TRUE, scale. = TRUE)

summary(pca_res)
screeplot(pca_res, type="lines")
biplot(pca_res, scale = 0)
loadings <- pca_res$rotation

# Visualización del PCA
fviz_pca_ind(pca_res,
             geom.ind = "point",
             pointshape = 21,
             pointsize = 2,
             fill.ind = "steelblue",
             col.ind = "black",
             repel = TRUE,
             title = "PCA ")

# Extraer los scores de los componentes principales
pca_res$x
pcs <- as.data.frame(pca_res$x)

# Combinar con la matriz original
with_pcs <- cbind(datos1, pcs)
df_with_pcs <- na.omit(with_pcs)
names(df_with_pcs)


df_with_pcs$Log_C_IMI_MAX<-log10(df_with_pcs$C_IMI_MAX+1)
summary(df_with_pcs$Log_C_IMI_MAX)


#VIF ANALISIS 
m1 <- glm(Log_C_IMI_MAX ~ NDVI_Aut+NDVI_Spri+NDVI_Sum+NDVI_Win+ANU_PLU+ANU_T_MAX+ANU_T_MED+ANU_T_MIN+T_agri+T_forest+P_capcap+P_cerela+PROV_ID+xcoord+ycoord, data = df_with_pcs)
vif(m1)

m2 <- glm(Log_C_IMI_MAX ~ NDVI_Aut+NDVI_Spri+NDVI_Sum+NDVI_Win+ANU_PLU+ANU_T_MAX+ANU_T_MIN+T_agri+T_forest+P_capcap+P_cerela+PROV_ID+xcoord+ycoord, data = df_with_pcs)
vif(m2)

m3 <- glm(Log_C_IMI_MAX ~ NDVI_Aut+NDVI_Spri+NDVI_Sum+NDVI_Win+ANU_PLU+ANU_T_MAX+ANU_T_MIN+T_agri+T_forest+P_capcap+P_cerela+PROV_ID+xcoord, data = df_with_pcs)
vif(m3)

m5 <- glm(Log_C_IMI_MAX ~ PC1+PC2+PC3+T_agri+T_forest+P_capcap+P_cerela+PROV_ID+xcoord+ycoord, data = df_with_pcs)
vif(m5)

m6 <- glm(Log_C_IMI_MAX ~ PC1+PC2+PC3+T_agri+T_forest+P_capcap+P_cerela+PROV_ID, data = df_with_pcs)
vif(m6)
88888888888

=======================
 SELECCION DEL MODELO 
=======================

# Stepwise AIC (dirección por defecto: ambos)
modelo_step <- step(m6, direction = "both")# "forward" "backward"

mF1 <- glm(Log_C_IMI_MAX ~ PC2 + T_forest + PROV_ID,data = df_with_pcs)
vif(mF1)
summary(mF1)

anova(mF1)
par(mfrow=c(2,3))
plot(mF1, which = c(1:6))
AIC(mF1)
durbinWatsonTest(mF1) # autocorrelacion

df_with_pcs$res1<-residuals(mF1) 
df_with_pcs$pred1<-fitted.values(mF1) 
par(mfrow=c(1,1))
plot(df_with_pcs$res1, df_with_pcs$Log_C_IMI_MAX) 
shapiro.test(df_with_pcs$res1)

88888888888888888888888888888888888888888

df_limpio <- df_with_pcs 

m7 <- step(glm.nb(C_IMI_MAX ~ PC1+PC2+PC3+T_agri+T_forest+P_capcap+P_cerela, data = df_limpio), direction=c("both"))

summary(m7)

m8 <-glm.nb( C_IMI_MAX ~ PC1 + PC2 + T_agri + T_forest + 
         P_capcap + P_cerela, data = df_limpio, link = log)

summary(m8)
par(mfrow=c(2,3))
plot(m8, which = c(1:6))
durbinWatsonTest(m8) 
df_with_pcs$res4<-residuals(m8) 
shapiro.test(df_with_pcs$res4)

88888888888888888888888888888888

library(lme4)

# Suponiendo que tus datos están agrupados por una variable 'PROV_ID'
# Si tu variable de agrupación tiene otro nombre, reemplázalo aquí.

m_glmer_nb <- glmer.nb(
  C_IMI_MAX ~ PC1 + PC2 + scale(T_agri) + scale(T_forest) + 
    P_capcap + P_cerela+ (1 | PROV_ID), # Este es el efecto aleatorio, '1' es para la intersección aleatoria
  data = df_limpio
)

summary(m_glmer_nb)

m_glmer_nb1 <- glmer.nb(
  C_IMI_MAX ~ PC1 + PC2  + scale(T_forest) + 
      P_cerela+ (1 | PROV_ID), # Este es el efecto aleatorio, '1' es para la intersección aleatoria
  data = df_limpio
)

summary(m_glmer_nb1)

library(effects)
plot(allEffects(m_glmer_nb1))

library(DHARMa)
sim_res <- simulateResiduals(m_glmer_nb1)
plot(sim_res)
testZeroInflation(sim_res)
testDispersion(sim_res)
testOutliers(sim_res)
testUniformity(sim_res)
