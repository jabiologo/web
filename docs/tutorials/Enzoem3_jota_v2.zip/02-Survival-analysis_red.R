#Survival Analysis
library(dplyr)
library(survival)
library(survminer)
  

head(lung)
class(lung)
dim(lung)
View(lung)

as_tibble(lung)
lung <- as_tibble(lung)
lung

#1.-CURVAS DE SUPERVIVENCIA
s <- Surv(lung$time, lung$status)
class(s)
s
# ajuste de la curva de supervivencia
survfit(s~1)
fit <- survfit(Surv(time, status)~1, data=lung)
fit
summary(fit)

#Curva de superviviencia por sexo
sfit <- survfit(Surv(time, status)~sex, data=lung)
sfit
summary(sfit)
range(lung$time)
summary(sfit, times=seq(0, 1000, 100))

#2.- Kaplan-Meier Plots
sfit <- survfit(Surv(time, status)~sex, data=lung)
plot(sfit)
?plot.survfit

     #library(survminer)
ggsurvplot(sfit)

# Más bonito
ggsurvplot(sfit, conf.int=TRUE, pval=TRUE, risk.table=TRUE, 
           legend.labs=c("Male", "Female"), legend.title="SEX",  
           palette=c("darkgreen", "purple"), 
           title="Kaplan-Meier Curve for Lung Cancer Survival", 
           risk.table.height=.15)


# Prueba de log-rank para comparar las curvas
survdiff(Surv(time, status) ~ sex, data = lung)


# Cox Regression

fit1 <- coxph(Surv(time, status)~sex, data=lung)
fit1

exp(0.531)

   # HR=1: Sin efecto
   # HR>1: Incremento del riesgo
   # HR<1: Reduction in hazard (protector)
   # 
summary(fit1)
survdiff(Surv(time, status)~sex, data=lung)

fit <- coxph(Surv(time, status)~sex+age+ph.ecog+ph.karno+pat.karno+meal.cal+wt.loss, data=lung)
fit


#Categorizando la edad

coxph(Surv(time, status)~age, data=lung)

ggsurvplot(survfit(Surv(time, status)~age, data=lung))#Upps

mean(lung$age)
hist(lung$age)
ggplot(lung, aes(age)) + geom_histogram(bins=20)
# agrupar y categorizar edad
cut(lung$age, breaks=c(0, 60, Inf))
cut(lung$age, breaks=c(0, 60, Inf), labels=c("young", "old"))
  
  # the base r way:
lung$agecat <- cut(lung$age, breaks=c(0, 60, Inf), labels=c("young", "old"))

  # or the dplyr way:
lung <- lung %>% 
  mutate(agecat=cut(age, breaks=c(0, 60, Inf), labels=c("young", "old")))

lung <- lung %>% 
  mutate(agecat1=cut(age, breaks=c(0, 50, 70, Inf), labels=c("young", "old", "ancient")))

head(lung)



head(lung)

ggsurvplot(survfit(Surv(time, status)~agecat1, data=lung), pval=TRUE)

sfit1<-survfit(Surv(time, status)~agecat1, data=lung)

ggsurvplot(sfit1, conf.int=TRUE, pval=TRUE, risk.table=TRUE, 
           legend.labs=c("young", "old", "ancient"), legend.title="Age",  
           palette=c("dodgerblue2", "orchid2", "green"), 
           title="Kaplan-Meier Curve for Lung Cancer Survival", 
           risk.table.height=.15)




