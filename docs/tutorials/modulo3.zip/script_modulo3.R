###############################################################
# Curso de Estadística ENZOEM 2025                            #
# José Antonio Blanco-Aguiar y Javier Fernández-López         #
# Módulo 3 - Modelos avanzados en estudios observacionales    #
# https://jabiologo.github.io/web/tutorials/enzoem_3.html     #
###############################################################

# Seleccionamos nuestro directorio de trabajo
setwd("mi_directorio_de_trabajo")
getwd()

##############################################################
# Caso 1: Efectos aleatorios en estudios observacionales     #
##############################################################

garrapatas <- read.csv("garrapatas_cotos.csv")



#######################################################
# Caso 2: Efectos aleatorios en medidas repetidas     #
#######################################################

repetidas <- read.csv("peso.csv")



#####################################################################
# Caso 3: Efectos aleatorios en medidas repetidas y caso/control    #
#####################################################################

farmaco <- read.csv("farmaco.csv")




############################################################
# Caso 3: Efectos aleatorios en estudios longitudinales    #
############################################################

longi <- read.csv("logitudinal.csv")

