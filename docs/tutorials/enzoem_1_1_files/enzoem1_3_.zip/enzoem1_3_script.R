##############################################################
       INTRO A VISUALIZACIÓN DE DATOS CON GGPLOT2
##############################################################
                      CURSO ENZOEM 2025
       Jose A Blanco-Aguiar & Javier Fernández-López
##############################################################

# Instalación (si se precisa) y carga de las librerias
   #install.packages(c("here", "tidyverse", "palmerpenguins","visdat"))
  
   library (here)  # para indicar directorio de trabajo
   library (tidyverse) # incluye ggplot2
   library (palmerpenguins) # librería fuente datos pinguinos
   library (visdat)# para explorar datos 

# llamar a los datos y exploración de su estructura
  data("penguins")
  names (penguins)
  head (penguins)
  summary(penguins)# hay NAs?
  str(penguins)# tipo de datos?
  visdat::vis_dat(penguins) # visualizacion datos
  visdat::vis_miss(penguins) # visualizacion NA
  
# Eliminamos NA (por comodidad)
  penguins1 <- penguins %>% drop_na()
  visdat::vis_dat(penguins1)
  
-----------------------------------------------------------
    
# GENERAR UNA GRAFICA BÁSICA
  # Representamos la longitud frente anchura del pico
  
    ggplot(data = penguins1, aes(x = bill_length_mm, y = bill_depth_mm)) + 
    geom_point(size = 4)
  
  # Generamos un objeto a partir de la gráfica generada
    p1<-ggplot(data = penguins1, aes(x = bill_length_mm, y = bill_depth_mm)) + 
    geom_point(size = 2)
    p1
  # Se incorpora una capa de informacion más
    p1 + geom_line(color = "firebrick")
    
  # Añadir Título y Etiquetas de los ejes
    ggplot(data = penguins1, 
           aes(x = bill_length_mm, y = bill_depth_mm))+
      geom_point(size=3) +
      labs(title = "Relación entre la longitud y anchura del pico",
           x = "Longitud del pico (mm)",
           y = "Anchura del pico (mm)")
    
  # Cambiar colores y tamaños
    ggplot(data = penguins1,
           aes(x = bill_length_mm, y = bill_depth_mm, 
               color = island, size = body_mass_g, 
               shape = species ))+
      geom_point() +
      labs(title="Relación entre la longitud y anchura del pico",
           x = "Longitud del pico (mm)",
           y = "Anchura del pico (mm)")
    
    
# FACETADO
  # Generar varias fráficas dividiendo los datos por una variable
    ggplot(data = penguins1,
           aes(x = bill_length_mm, y = bill_depth_mm))+
      geom_point() +
      geom_line(color = "blue", linewidth = 0.2)+ 
      facet_wrap(~ species) +
      labs(title="Relación entre la longitud y anchura del pico",
           x = "Longitud del pico (mm)",
           y = "Anchura del pico (mm)")
    
# TEMAS
    ggplot(data = penguins1,
    mapping = aes(x = bill_length_mm, y = bill_depth_mm))+
      geom_point(color = "#8B8878", size = 2) +
      theme_minimal() +
      facet_wrap(~ species) +
      geom_smooth(aes(colour = "loess"), method = "loess", se = F) +                  
      geom_smooth(aes(colour = "lm"), method = "lm", se = FALSE) +  
      labs(title="Relación entre la longitud y anchura del pico",
           x = "Longitud del pico (mm)",
           y = "Anchura del pico (mm)")

# COLORES

  # Cambio del color de los puntos en base a una variable    
    ggplot(data = penguins1,
           aes(x= bill_length_mm, y= bill_depth_mm, color=island))+
      geom_point(size = 2) +
      theme_minimal() +
      facet_wrap(~ species) +
      geom_smooth(aes(colour = "loess"), method = "loess", se = F) +                
      geom_smooth(aes(colour = "lm"), method = "lm", se = FALSE) +  
      labs(title="Relación entre la longitud y anchura del pico",
           x = "Longitud del pico (mm)",
           y = "Anchura del pico (mm)")+
      theme(axis.text = element_text(color = "blue", size = 12),
            axis.text.x = element_text(face = "italic"))
    
  # Seleccion manual de los colores
    ggplot(data = penguins1,
           aes(x= bill_length_mm, y= bill_depth_mm, color=island))+
      geom_point(size = 2) +
      scale_color_manual(values = c("darkorange", "darkorchid", "cyan4","red","black"))+
      theme_minimal() +
      facet_wrap(~ species) +
      geom_smooth(aes(colour = "loess"), method = "loess", se = F) +  
      geom_smooth(aes(colour = "lm"), method = "lm", se = FALSE) +  
      labs(title="Relación entre la longitud y anchura del pico",
           x = "Longitud del pico (mm)",
           y = "Anchura del pico (mm)")+
      theme(axis.text = element_text(color = "blue", size = 12),
            axis.text.x = element_text(face = "italic"))
    
  # Longitud de las aletas frente al peso de los animales 
  # diferenciando las especies por color y forma
    
    ggplot(data=penguins1,aes(x= flipper_length_mm, y= body_mass_g))+
      geom_point(aes(color = species, 
                     shape = species,
                     size = 1))+
      geom_smooth(aes(group = species,color = ""), method = "lm", se = T) +
      scale_color_manual(values = c("orange","purple","cyan4", "black"))+
      theme_minimal()
  
  # Uso de librería de paletas
    library(RColorBrewer)
    
    ggplot(data = penguins1, aes(x = bill_length_mm, y = bill_depth_mm, color = species)) +
      geom_point(size=3) +
      scale_color_brewer(palette = "Set2") +
      theme_minimal()

# EXPLORANDO OTRAS GEOMETRIAS

  # Histograma
    ggplot(data = penguins1, mapping = aes(x=bill_length_mm))+
      geom_histogram (aes(fill = species), alpha = 0.4, position = "identity") + 
      scale_fill_manual(values = c("orange","orchid","cyan2"))
    
  # Densidades
    ggplot(data = penguins1, mapping = aes(x = bill_length_mm)) +
      geom_density(aes(fill = species), alpha = 0.4, position = "identity") +
      scale_fill_manual(values = c("orange", "orchid", "cyan2")) +
      labs(title = "Proportional density")  
  
  # Gráfico de barras
    ggplot(data = penguins1, aes(x = factor(species))) +
      geom_bar(fill = "skyblue", color = "black") +
      labs(title = "Número de pinguinos por espcie ",
           x = "Especies de pinguinos",
           y = "Frecuencia") +
      theme_minimal()
    
  # Conteo número de individuos por especie e isla
    ggplot(penguins1, aes(x = island, fill = species)) +
    geom_bar(alpha = 0.8) +
      scale_fill_manual(values = c("orange","orchid","cyan4"), 
                        guide = "none") +
      theme_minimal() +
      facet_wrap(~species, ncol = 1) +
      coord_flip()
    
  # Barras apiladas
  # Conteo número de individuos por especie, isla y sexo
    ggplot(penguins1, aes(x = island, fill = interaction(species, sex))) +
      geom_bar(alpha = 0.8) +
      scale_fill_manual(values = c("orange", "orchid", "cyan4", "lightblue", "plum", "darkgreen"), 
                        guide = guide_legend(title = "Species and Sex")) +
      theme_minimal() +
      facet_wrap(~species, ncol = 1) +
      coord_flip ()
    
  # Gráfico de cajas
    ggplot(data = penguins1, aes(x = species, y= body_mass_g)) +
      geom_boxplot(fill = "skyblue", color = "black") +
      labs(title = "Peso de los animales por espcie ",
           x = "Especies de pinguinos",
           y = "Peso") +
      theme_minimal()
    
    
  
  # Translocar ejes    
    pc<-ggplot(data = penguins1, aes(x = species, y= body_mass_g)) +
      geom_boxplot(fill = "indianred", color = "black") +
      labs(title = "Peso de los animales por espcie ",
           x = "Especies de pinguinos",
           y = "Peso") +
      theme_minimal()
    
    pc+ coord_flip()
    
  # Simplificar llamada
    ggplot(penguins1, aes(species, body_mass_g)) +
      geom_boxplot(fill = "skyblue", color = "black") +
      labs(title = "Peso de los animales por espcie ",
           x = "Especies de pinguinos",
           y = "Peso") +
      theme_minimal()  
    
  
    # Combinando diferentes gráficos 
    # (Grafíco de Violín y distribución de los puntos)
    
    pc+ coord_flip()+ 
      geom_violin(alpha=0.5)+ 
      geom_jitter(aes(color=species),
                  alpha=0.5, 
                  position = position_jitter(width = .2))
    
----------------------------------------------------------------
  
  EJERCICIOS CON GGPLOT
    
  Base de datos sobre descriptivos de la características de vehículos
   
    mpg  -	Millas/ por galon de combustible
    cyl  -	Numero de cilindros
    disp -	Desplazamiento
    hp   -	Caballos de potencia
    drat -	Relación del eje trasero
    wt   -	Peso en libras
    qsec -	aceleración
    vs   -	Motor (0 = en V, 1 =directo)
    am   -	Transmision (0 = automatico, 1 = manual)
    gear -	Número de marchas
    
    ¿tiene esta matriz valores perdidos?
    ¿como se relaciona el peso (wt) con las millas consumidas por galón (mpg)?
    Une los puntos del scaterplot con líneas  
    Modifica los nombres de los ejes al castellano
    Cambia el color de los puntos en función al número de cilindros y el tamaño de los puntos en función de los caballos de potencia. 
    Incorpora ajustes de suavizado y lineales.
    Genera graficos con facetas dependiendo del número de cilindros
    Genera histogramas para la aceleración
-------------------------------------------------------------------      
    
      
    data(mtcars)
    head (mtcars)
    
    
    
   