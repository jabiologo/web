88888888888888888888888888888888888888888888
MODULO III - ENZOEM - análisis multivariante
88888888888888888888888888888888888888888888

## Instalar y cargar paquetes necesarios
library(palmerpenguins) # fuente de datos
library(cluster) # Clusters
library(dendextend)# dendogramas
library(NbClust)# número óptimo de clusters


## Preparar los datos ¿que variables usamos?
data <- na.omit(penguins[, c("species", "bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g")])
df <- scale(data[, -1])  # Excluye la columna 'species' para poder escalar variables

# -------------------------
# ANALISIS DE AGRUPAMIENTO
# -------------------------

# 1. K-means clustering
set.seed(123)
km_res <- kmeans(df, centers = 2, nstart = 25)
fviz_cluster(km_res, data = df) + ggtitle("K-means Clustering")

km_res <- kmeans(df, centers = 3 , nstart = 25)
fviz_cluster(km_res, data = df) + ggtitle("K-means Clustering")

km_res <- kmeans(df, centers = 4, nstart = 25)
fviz_cluster(km_res, data = df) + ggtitle("K-means Clustering")

# --------------------------
# 2. Clustering jerárquico
# --------------------------

## Opciones de calculos de distancias

#----- Distancia Euclidiana -----
dist_euc <- dist(df, method = "euclidean")

# Distancia Manhattan
dist_man <- dist(df, method = "manhattan")

# Distancia de Canberra
dist_can <- dist(df, method = "canberra")

# Distancia de Minkowski (p=3)
dist_mink <- dist(df, method = "minkowski", p = 3)


# EJEMPLO ----

dist_matrix <-dist_euc
hc_res <- hclust(dist_matrix, method = "ward.D2")
dend <- as.dendrogram(hc_res)
dend_colored <- color_branches(dend, k = 3)

par(mfrow = c(1, 1))  # Panel gráfico único
plot(dend_colored, main = "Clustering Jerárquico", labels = T)
rect.hclust(hc_res, k = 8, border = 2:4)

# ------------------------------------
# 3. PAM (Partitioning Around Medoids)
# ------------------------------------

pam_res <- pam(df, k = 3)
fviz_cluster(pam_res, data = df) + ggtitle("PAM Clustering")
# Índice de silueta
fviz_silhouette(pam_res)
#dev.new()

# ------------------------------------
## Selección deL número de grupos ##
# ------------------------------------

# Método del codo (Elbow method)
fviz_nbclust(df, kmeans, method = "wss")
# Índice de silueta
fviz_nbclust(df, kmeans, method = "silhouette")
# Gap Statistic
library(cluster)
set.seed(123)
gap_stat <- clusGap(df, FUN = kmeans, nstart = 25, K.max = 10, B = 50)
fviz_gap_stat(gap_stat)
#Nb Clust
library(NbClust)
nb <- NbClust(df, distance = "euclidean", min.nc = 2, max.nc = 10, method = "kmeans")
fviz_nbclust(nb)

888888888888888888888888888888888888888888888888888888888u

## ------------------------------------
## ANALISIS DE COMPONENTES PRINCIPALES
## ------------------------------------
library(factoextra)# PCA
# -------------------------------
# 1. PCA (Análisis de Componentes Principales)
pca_res <- prcomp(df, center = TRUE, scale. = TRUE)

summary(pca_res)
sum((pca_res$sdev)^2)
screeplot(pca_res, type="lines")


# Visualización del PCA
fviz_pca_ind(pca_res,
             geom.ind = "point",
             pointshape = 21,
             pointsize = 2,
             fill.ind = "steelblue",
             col.ind = "black",
             repel = TRUE,
             title = "PCA - Palmer Penguins")

pca_res <- prcomp(df, center = TRUE, scale. = TRUE)

fviz_pca_ind(pca_res,
             geom.ind = "point",
             pointshape = 21,
             pointsize = 2,
             fill.ind = data$species,  # Colores por especie
             col.ind = "black",
             legend.title = "Especie",
             repel = TRUE,
             title = "PCA - Palmer Penguins")


# Extraer los scores de los componentes principales
pca_res$x
pcs <- as.data.frame(pca_res$x)

# Combinar con la matriz original
df_with_pcs <- cbind(df, pcs)

# ----------------------------------
# 2. MDS (Escalado Multidimensional)
# ----------------------------------

dist_matrix <- dist(df)
mds_res <- cmdscale(dist_matrix, k = 2)

# Visualización del MDS
mds_df <- as.data.frame(mds_res)
colnames(mds_df) <- c("Dim1", "Dim2")

plot(mds_df$Dim1, mds_df$Dim2,
     xlab = "Dimensión 1", ylab = "Dimensión 2",
     main = "MDS - Palmer Penguins",
     pch = 21, bg = "lightgreen", col = "black")

#dist_matrix <- dist(df)
mds_res <- cmdscale(dist_matrix, k = 2)
mds_df <- as.data.frame(mds_res)
mds_df$species <- data$species

#Nos ponemos guapos
library(ggplot2)
ggplot(mds_df, aes(x = V1, y = V2, color = species)) +
  geom_point(size = 3) +
  labs(title = "MDS - Palmer Penguins",
       x = "Dimensión 1", y = "Dimensión 2") +
  theme_minimal()



library(MASS)
d <- dist(mds_res) # distancias euclidianas entre las filas
fit <- isoMDS(d, k=2) # número de dim
fit # ver resultados, e,g stress <5 excelebte 5-10 bueno

# validación
shep <- Shepard(d, fit$points)
plot(shep, pch = ".")
lines(shep$x, shep$y, type = "S")

# plot solution
x <- fit$points[,1]
y <- fit$points[,2]
plot(x, y, xlab="Coordinate 1", ylab="Coordinate 2", main="Nonmetric MDS",
     pch = 21, bg = "lightgreen", col = "black")

88888888888888888888888888888888
PERMANOVA adonis2()
88888888888888888888888888888888

# Cargar el paquete
library(vegan)
?dune
# Cargar los datos
data(dune)
data(dune.env)

head(dune) # Matriz de abundancia de especies
head(dune.env)
levels(dune.env$Manure)
levels(dune.env$Use)
levels(dune.env$Management)

distancia <- vegdist(dune, method = "bray")

resultado <- adonis2(distancia ~ Management, data = dune.env, permutations = 999)
print(resultado)

disper <- betadisper(distancia, dune.env$Management)
anova(disper) #homogeneidad de dispersion
plot(disper)

disper2 <- betadisper(distancia, dune.env$Use)
anova(disper2)
plot(disper2)

disper3 <- betadisper(distancia, dune.env$Moisture)
plot(disper3)
anova(disper3)

modelo1 <- adonis2(distancia ~ Management, data = dune.env)
modelo2 <- adonis2(distancia ~ Management + Use, data = dune.env)
modelo3 <- adonis2(distancia ~ Management + Use + Moisture, data = dune.env)

modelo1$R2[1]
modelo2$R2[1]
modelo3$R2[1]

888888888888888888888888888888

dune.env1 <- dune.env [,-5]
names(dune.env1)

# Modelo nulo (sin variables)
modelo_nulo <- rda(dune ~ 1, data = dune.env1)

# Modelo completo (con todas las variables)
modelo_completo <- rda(dune ~ ., data = dune.env1)

seleccion <- ordiR2step(modelo_nulo, scope = formula(modelo_completo), direction = "forward", R2scope = TRUE, permutations = 999)

summary(seleccion)

# Aplicar betadisper
grupos <- dune.env$Management
dispersión <- betadisper(distancia, grupos)

# 3. Ver resultados
summary(dispersión)
anova(dispersión)         # prueba de significancia
permutest(dispersión)     # prueba por permutación
plot(dispersión)          # visualización
