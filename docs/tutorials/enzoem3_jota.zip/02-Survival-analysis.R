#Survival Analysis
library(dplyr)
library(survival)
library(survminer)


head(lung)
class(lung)
dim(lung)
View(lung)

as_tibble(lung)
lung <- as_tibble(lung)
lung

#1.-CURVAS DE SUPERVIVENCIA
s <- Surv(lung$time, lung$status)
class(s)
s
# ajuste de la curva de supervivencia
survfit(s~1)
fit <- survfit(Surv(time, status)~1, data=lung)
fit
summary(fit)

#Curva de superviviencia por sexo
sfit <- survfit(Surv(time, status)~sex, data=lung)
sfit
summary(sfit)
range(lung$time)
summary(sfit, times=seq(0, 1000, 100))

#2.- Kaplan-Meier Plots
sfit <- survfit(Surv(time, status)~sex, data=lung)
plot(sfit)

     #library(survminer)
ggsurvplot(sfit)

# Más bonito
ggsurvplot(sfit, conf.int=TRUE, pval=TRUE, risk.table=TRUE, 
           legend.labs=c("Male", "Female"), legend.title="SEX",  
           palette=c("darkgreen", "purple"), 
           title="Kaplan-Meier Curve for Lung Cancer Survival", 
           risk.table.height=.15)

# Cox Regression

fit1 <- coxph(Surv(time, status)~sex, data=lung)
fit1

exp(0.531)

   # HR=1: No effect
   # HR>1: Increase in hazard
   # HR<1: Reduction in hazard (protective)
   # 
summary(fit1)
survdiff(Surv(time, status)~sex, data=lung)

fit <- coxph(Surv(time, status)~sex+age+ph.ecog+ph.karno+pat.karno+meal.cal+wt.loss, data=lung)
fit

#Categorizando la edad

coxph(Surv(time, status)~age, data=lung)

ggsurvplot(survfit(Surv(time, status)~age, data=lung))#Upps

mean(lung$age)
hist(lung$age)
ggplot(lung, aes(age)) + geom_histogram(bins=20)
# agrupar y categorizar edad
cut(lung$age, breaks=c(0, 60, Inf))
cut(lung$age, breaks=c(0, 60, Inf), labels=c("young", "old"))
  
  # the base r way:
lung$agecat <- cut(lung$age, breaks=c(0, 60, Inf), labels=c("young", "old"))

  # or the dplyr way:
lung <- lung %>% 
  mutate(agecat=cut(age, breaks=c(0, 60, Inf), labels=c("young", "old")))

head(lung)


# the base r way:
lung$agecat <- cut(lung$age, breaks=c(0, 62, Inf), labels=c("young", "old"))

# or the dplyr way:
lung <- lung %>% 
  mutate(agecat=cut(age, breaks=c(0, 62, Inf), labels=c("young", "old")))

head(lung)

ggsurvplot(survfit(Surv(time, status)~agecat, data=lung), pval=TRUE)


8888888888888888888888888888888888888888888888888888888888888888888888888
library(survival)
library(KMsurv)
library(ggplot2)
data("tongue")
library(survminer)
?tongue
head(tongue)


#Estimación no-paramétrica de la función de supervivencia
# Guardando el Objeto Surv
tongue.surv <- Surv(tongue$time, tongue$delta)  #Creando objeto tipo Surv
tongue.km <- survfit(tongue.surv ~ 1, data = tongue, type = "kaplan-meier")  #Estimación Kaplan Meier

# Sin Guardar el Objeto Surv
tongue.km <- survfit(Surv(time, delta) ~ 1, data = tongue, type = "kaplan-meier")
summary(tongue.km)

# time : Tiempo de la observación
# n.risk : El número de sujetos en riesgo.
# n.evento : El número de sujetos que presentaron el evento.
# survival : La estimación de la función de supervivencia.
# std.err : La desviación estándar de la estimación.
# lower y upper CI* : Los intervalos de confianza para la estimación.

tongue.km <- survfit(Surv(time, delta) ~ type, data = tongue, type = "kaplan-meier")  #Estimación Kaplan Meier por grupos
summary(tongue.km)  #Resumen estadístico 

#Graficación de la curva de supervivencia

tongue.km <- survfit(Surv(time, delta) ~ 1, data = tongue, type = "kaplan-meier", 
                     error = "tsiatis", conf.type = "log-log", conf.int = 0.99)

summary(tongue.km)
plot(tongue.km)
ggsurvplot(fit = tongue.km, data = tongue, conf.int = T, title = "Curva de Supervivencia", 
           xlab = "Tiempo", ylab = "Probabilidad de supervivencia", legend.title = "Estimación", 
           legend.labs = "Kaplan-Meier")

# Estimación de la función de riesgo acumulado

tongue.km <- survfit(Surv(time, delta) ~ type, tongue)
R <- tongue.km %>% fortify %>% group_by(strata) %>% mutate(CumHaz = cumsum(n.event/n.risk))
print(R, 60)

library(broom)
tidy(tongue.km)

R <- tidy(tongue.km) %>% group_by(strata) %>% mutate(CumHaz = cumsum(n.event / n.risk))

plot(tongue.km, fun = "cumhaz", conf.int = F, main = "Riesgo Acumulado", col = 1:2, 
     xlab = "Tiempo (Semanas)", ylab = "Riesgo Acumulado")

ggsurvplot(tongue.km, fun = "cumhaz", xlab = "Tiempo (Semanas)", censor = T, 
           ylab = "Riesgo Acumulado", title = "Riesgo Acumulado", legend.title = "Perfil de ADN tumoral", legend.labs = c("Aneuploide", "Diploide"))

8888888888888888888888888888888888888888888888888888888888888888
#https://whitlockschluter3e.zoology.ubc.ca/RExamples/Rcode_Chapter_21.html

library(ggplot2)
library(survival)
library(survminer)

ebola <- read.csv(url("https://whitlockschluter3e.zoology.ubc.ca/Data/chapter21/chap21e1EbolaMalaria.csv"))
head(ebola)

#Survival curve

ebolaSurv <- Surv(time = ebola$time, event = ebola$outcome)
ebolaKM <- survfit(ebolaSurv ~ 1, data = ebola, type="kaplan-meier") 

ggsurvplot(ebolaKM, conf.int = TRUE, pval = FALSE, risk.table = FALSE, 
           legend = "none", censor.shape = "|", censor.size = 4, palette = c("firebrick"), 
           ylab = "Proportion surviving", xlab = "Time (days since admission)")

#Proportion surviving
summary(ebolaKM, censored = FALSE)

#Median survival time
ebolaKM


