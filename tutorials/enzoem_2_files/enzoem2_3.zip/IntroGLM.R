################################
# MODULO 2 ESTADISTICA ENZOEM
################################
library (here)
#cargamos BD de pinguinos y eliminamos NAs por comodidad
library(palmerpenguins)
data("penguins")
head(penguins)

library(tidyverse)
penguins1 <- penguins %>% drop_na()

#corremos un modelo lineal

peng <- lm(body_mass_g ~ flipper_length_mm + bill_depth_mm + species + year, data = penguins1)
summary(peng) # equivalente ANOVA tipo III
anova(peng) #equivalente ANOVA tipo I(secuencial)

peng0 <- lm(body_mass_g ~bill_depth_mm+ flipper_length_mm + species + year , data = penguins1)
summary(peng0)
anova(peng0)

library(car)
Anova(peng , type = "II") # Tipo II
Anova(peng , type = "III") # Tipo III

#introducimos la interacción
peng1 <- lm(body_mass_g ~ flipper_length_mm + species*year, data = penguins1)

peng2<- lm(body_mass_g ~ flipper_length_mm +species+year+ species:year, data = penguins1)
summary(peng1)
summary(peng2)
anova(peng1)

# REPRESETACIÓN GRÁFICA
library(ggplot2)

ggplot(penguins1, aes(x = factor(year), y = body_mass_g, color = island, group = island)) +
  stat_summary(fun = mean, geom = "line") +
  stat_summary(fun = mean, geom = "point") +
  stat_summary(fun.data = mean_se, geom = "errorbar", width = 0.2) +
  labs(x = "Año", y = "Masa corporal (g)", color = "Isla") +

#VALIDACIONES DEL MODELO 
par(mfcol = c(2, 2))
plot(peng1)
shapiro.test(residuals(peng1))#valorar normalidad

library(car)
leveneTest(residuals(peng1) ~ species, data = penguins1)
durbinWatsonTest(peng1) # VALORAR AUTOCORRELACION RESIDUOS ~2

8888888888888888888888888888888888888888888888888


# Generar datos ficticios
set.seed(123) # Para reproducibilidad
n <- 100
meses <- sample(1:12, n, replace = TRUE)
sexo <- sample(c("M", "F"), n, replace = TRUE)
peso <- rnorm(n, mean = 70, sd = 10)

# Crear el data frame
misdatos <- data.frame(meses, sexo, peso)

# Definir la fórmula y la familia
formula <- peso ~ meses * sexo
familia <- gaussian(link = "identity")

# Ajustar el modelo GLM
modelo <- glm(formula, data = misdatos, family = familia)

# Mostrar los resultados del modelo
summary(modelo)
#plotear los residuos
dev.off()

shapiro.test(residuals(modelo))

AIC(modelo)
#modelo nulo
modelo0 <- glm(peso ~ 1, data = misdatos, family = familia)
AIC(modelo0,modelo)


# Cargar la librería necesaria
library(lmtest)

# Realizar la prueba de Breusch-Pagan (homocedasticidad)
# Hipótesis nula (H0): No hay heterocedasticidad (los residuos tienen varianza constante).
bptest(modelo)

# Cálculo de la R2
library(rsq)
r2 <- rsq(modelo, type = "sse")
r2

# Calcular el pseudo R-cuadrado
library(pscl)
pseudo_r2 <- pR2(modelo)
pseudo_r2

# EJERCICIO TRIAZOLES PERDICES
#La concentración de triazoles están afectados por el peso, sexo y el tipo de habitat

8888888888888888888888888888888888888 
GLM - BINOMIAL
8888888888888888888888888888888888888 

------------------------------------
  ## GENERALIZED LINEAR MODEL - LOGISTIC REGRESSION
  
  boar<- read.csv("boar.csv", sep=";", header=TRUE) 
names(boar) 

# Outliers

par(mfrow=c(1,1))
boxplot(boar$LengthCT, main="LengthCT")

# Transformación de variables

boar$LogLengthCT<-log(boar$LengthCT,10)

boar$Tb_f<-as.factor(boar$Tb)
boar$SEX_f<-as.factor(boar$SEX)
boar$AgeClass_f<-as.factor(boar$AgeClass)

str(boar)

# Contingency tables to explore for balanced designs

table(boar$Tb_f, boar$SEX_f)
table(boar$Tb_f, boar$AgeClass_f)

# Performing the model

modelo_LG<-glm (Tb_f ~ LogLengthCT , family=binomial("logit"), data=boar)
summary(modelo_LG)
anova(modelo_LG)
exp(modelo_LG$coefficients) # coefficient extraction - odds ratio

boar$P<-predict(modelo_LG,boar,type="response")
plot(boar$LogLengthCT, boar$P)


# Calcular la desviación residual y los grados de libertad
desviacion_residual <- sum(residuals(modelo_LG, type = "deviance")^2)
grados_libertad <- df.residual(modelo_LG)

# Calcular el factor de sobredispersión
factor_sobredispersion <- desviacion_residual / grados_libertad
factor_sobredispersion  # <2 No hay sobre dispersión

---------------------------------------
# EJERCICIO PRACTICO:  LogLengthCT+SEX_f*AgeClass_f
# EJERCICIO PRACTICO: 
#dataB <- read.csv("binomial.csv")
#resultado ~ predictor
# Modelo de regresión logística
---------------------------------------
# Sobredispersión detectada
     modelo_quasi <- glm(Tb_f ~ LogLengthCT, family = quasibinomial, data = boar)
# Resumen del modelo ajustado
    summary(modelo_quasi)

00000000000000000000
# GLM proporciones #
00000000000000000000
    
library(faraway)
data(beetle)
str(beetle)  
attach(beetle)
yprop <- affected/exposed
plot(yprop ~ conc, ylab = "Proporción de insectos afectados", xlab = "Concentracion de pesticida") 

y <- cbind(affected, exposed - affected)
glm.beetle1 <- glm(y ~ conc, family = binomial)
glm.beetle0 <- glm(yprop ~ conc)
summary(glm.beetle1)

par(mfcol = c(2, 2))
plot(glm.beetle1)
    

88888888888888888888888888888888888888
## GENERALIZED LINEAR MODELS - Poisson
88888888888888888888888888888888888888


library(here)
road<- read.csv("Roadkills.csv", sep=";", header=TRUE)
names(road)
str(road)


# Transforming variables
modelo_poisson <- glm ( TOT.N ~ OPEN.L+D.WAT.RES+D.PARK, family=poisson("log"), data=road)
summary(modelo_poisson)
par(mfrow=c(2,3))
plot(modelo_poisson, which = c(1:6))
library(effects)
plot(allEffects(modelo_poisson))


# Calcular la devianza residual y los grados de libertad residuales
devianza_residual <- sum(residuals(modelo_poisson, type = "pearson")^2)
grados_libertad_residual <- df.residual(modelo_poisson)

# Calcular el factor de sobredispersión
factor_sobredispersion <- devianza_residual / grados_libertad_residual
print(factor_sobredispersion)

#validacion del modelo
road$res_glm4<-residuals(modelo_poisson) 
road$pred_glm4<-fitted.values(modelo_poisson)
par(mfrow=c(2,2))
plot(modelo_poisson)
par(mfrow=c(1,1)) 
plot(road$res_glm4~road$D.PARK)
abline(h=0, col="red",lwd=2,lty=2, cex=2)


# Obtener la devianza nula y residual
devianza_nula <- modelo_poisson$null.deviance
devianza_residual <- modelo_poisson$deviance

# Calcular la devianza explicada
devianza_explicada <- devianza_nula - devianza_residual
porcentaje_explicado <- (devianza_explicada / devianza_nula) * 100
print(porcentaje_explicado)


8888888888888888888888888888888888888    
# HETEROGENIDAD DE LA VARIANZA - GLS
8888888888888888888888888888888888888
# TESTIS SIZE DATA BASE
library(here)
testis<-read.csv("TestisW.csv")
head(testis)
names(testis)
str(testis)

testis$fMONTH <- factor(testis$MONTH)
M1 <-lm(Testisweight~SIZE * fMONTH, data = testis)
op <- par(mfrow = c(2, 2), mar = c(4, 4, 2, 2))
plot(M1, which = c(1), col = 1, add.smooth = FALSE,
       caption = "")
plot(testis$fMONTH, resid(M1), xlab = "MONTH",
       ylab = "Residuals")
plot(testis$SIZE, resid(M1), xlab = "SIZE",
       ylab = "Residuals")
par(op)
plot (M1)

888888888888888888888

library(nlme)
# Heterogeneidad por tamaño
M.lm <- gls(Testisweight~SIZE * fMONTH, data=testis)
vf1Fixed <- varFixed(~SIZE)
M.gls1 <- gls(Testisweight ~ SIZE * fMONTH,
                weights = vf1Fixed, data = testis)
anova(M.lm, M.gls1)
AIC(M.lm, M.gls1)

# Heterogenidad mensual?
vf2 <- varIdent(form= ~ 1 | fMONTH)
M.gls2 <- gls(Testisweight ~ SIZE*fMONTH, data =testis,
                weights = vf2)
AIC(M.lm, M.gls1, M.gls2)
anova(M.lm, M.gls1, M.gls2)

plot(M.lm,which = c(1), col = testis$fMONTH,
     add.smooth = FALSE, caption = "")

E <- resid(M.lm)
coplot(E ~ SIZE | fMONTH, data = testis)

# 
vf3 <- varPower(form =~ SIZE)
M.gls3 <- gls(Testisweight ~ SIZE * fMONTH,
                weights = vf3, data = testis)

AIC(M.lm, M.gls1, M.gls2, M.gls3)

vf4 <- varPower(form =~ SIZE | fMONTH)
M.gls4 <- gls(Testisweight ~  SIZE * fMONTH,
                data = testis, weights = vf4)

AIC(M.lm, M.gls1, M.gls2, M.gls3, M.gls4)

plot(M.gls4)

plot(M.gls3, which = c(1), col = 1, add.smooth = FALSE,
     caption = "")
op <- par(mfrow = c(1, 2), mar = c(4, 4, 2, 2))
plot(testis$fMONTH, resid(M.gls4), xlab = "MONTH",
     ylab = "Residuals")
plot(testis$SIZE, resid(M.gls4), xlab = "SIZE",
     ylab = "Residuals")
par(op)

###############################
## MODELOS MIXTOS MULTINIVEL ##
###############################

###################################
# Diseño completamente aleatorizado
###################################

# Cargar librerías necesarias
library(lme4)
library(effects)

# Leer los datos
Ciervos <- read.csv("antiparasitario_ciervos.csv")

# Convertir variables a factores
Ciervos$Coto <- factor(Ciervos$Coto)
Ciervos$Tratamiento <- factor(Ciervos$Tratamiento)
Ciervos$Tiempo <- factor(Ciervos$Tiempo)
Ciervos$Sujeto <- factor(paste(Ciervos$Coto, Ciervos$Tratamiento, Ciervos$Sujeto, sep = "_"))

# Ajustar modelo mixto con distribución Poisson
modeloC <- glmer(CargaP ~ Tratamiento * Tiempo + (1 | Coto) + (1 | Sujeto),
                data = Ciervos,
                family = poisson)

# Resumen del modelo
summary(modeloC)

# Graficar efectos estimados
plot(allEffects(modeloC))


library(DHARMa)

# Crear simulaciones de residuos
sim_res <- simulateResiduals(fittedModel = modeloC)
# Graficar los residuos simulados
plot(sim_res)
testZeroInflation(sim_res)
testDispersion(sim_res)
testOutliers(sim_res)
testUniformity(sim_res)

